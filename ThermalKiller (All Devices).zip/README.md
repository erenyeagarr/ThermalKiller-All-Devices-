<hr>
universal Thermal Killer :v
<hr>

